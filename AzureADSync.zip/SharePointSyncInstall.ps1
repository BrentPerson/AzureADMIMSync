﻿<#
    Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
    THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
    INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
    We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object
    code form of the Sample Code, provided that. You agree: (i) to not use Our name, logo, or trademarks to market Your software
    product in which the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product in which the
    Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or
    lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

    .Synopsis
        This Script will create the required Metaverse Mappings that are required for the Azure AD and SharePoint 2019 Management Agents
        You will have to Specifiy the location of the supporting Files required under the $Path variable
    
    .Example 

       $Path = "C:\Temp\MIM\Install Script"

    .Author
        Brent Person
#>

$Path = "C:\Temp\MIM\Install Script"

function Publish-SynchronizationAssembly
{
    [CmdletBinding()]
    [OutputType([void])]
    Param
    (
        # Path to the source code file
        [ValidateScript({
        if (-not(Test-Path $_ -PathType Leaf))
        {
            throw "Source code file not found: $_"
        } 
        else
        {
            Write-Verbose "Verified $_ exists."
            return $true
        }      
        })] 
        [String]
        $Path
    )
    $ExtensionsFolder = Join-Path (Get-SynchronizationServicePath) Extensions
    Write-Verbose "Assembly will be output to: $ExtensionsFolder"

    if (-not(Test-Path -Path $ExtensionsFolder -PathType Container))
    {
        throw "Extensions folder not found: $ExtensionsFolder"
    }

    $SynchronizationAssembly = Join-Path (Get-SynchronizationServicePath) Bin\Assemblies\Microsoft.MetadirectoryServicesEx.dll
    Write-Verbose "Assembly will reference: $SynchronizationAssembly"
    if (-not(Test-Path -Path $SynchronizationAssembly -PathType Leaf))
    {
        throw "Microsoft.MetadirectoryServicesEx.dll assembly not found: $SynchronizationAssembly"
    }

    Write-Verbose "Calling Add-Type to build and output the assembly..."
    Add-Type -Path $Path -ReferencedAssemblies $SynchronizationAssembly -OutputType Library -OutputAssembly (Join-Path $ExtensionsFolder SharePointSynchronization.dll)
    Write-Verbose "Done."
}

function Get-SynchronizationServiceRegistryKey
{
	### The registry location depends on the version of the sync engine (it changed in FIM2010)
	$synchronizationServiceRegistryKey = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\miiserver -ErrorAction silentlycontinue
	if (-not $synchronizationServiceRegistryKey )
	{
	    $synchronizationServiceRegistryKey = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\FIMSynchronizationService -ErrorAction silentlycontinue
	}    

    ### Only output if we found what we were looking for
	if ($synchronizationServiceRegistryKey)
    {
        Write-Verbose ("Found the key: {0}" -F $synchronizationServiceRegistryKey.PSPath)
        Write-Output $synchronizationServiceRegistryKey
    }
    else
	{
	    Write-Warning "Synchronization Service does not seem to be installed on this computer."	    
	}
}

function Get-SynchronizationServicePath
{
    $synchronizationServiceRegistryKey = Get-SynchronizationServiceRegistryKey
    Get-ItemProperty -Path (Join-Path $synchronizationServiceRegistryKey.PSPath Parameters) | Select-Object -ExpandProperty Path
}

Import-Module -Name "C:\Program Files\Microsoft Forefront Identity Manager\2010\Synchronization Service\UIShell\Microsoft.DirectoryServices.MetadirectoryServices.Config.dll" 

Write-Host "Importing the Synchronization Service configuration"
Write-Host "Path: $Path"
Import-MIISServerConfig -Path $Path -Verbose    

Write-Host "Publishing the Sync Rules Extension DLL to the Sychronization Service extensions folder"      
Publish-SynchronizationAssembly -Path (Join-Path $Path SynchronizationRulesExtensions.cs) -Verbose
